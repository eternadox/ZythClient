package me.wavelength.baseclient.thealtening;

public class UserSkin {

	private final AlteningAlt account;

	public UserSkin(AlteningAlt account) {
		this.account = account;
	}

	public AlteningAlt getAccount() {
		return account;
	}

}