package me.wavelength.baseclient;

import me.wavelength.baseclient.AltManager.AltManager;

public class FunniNEW {
	
	
	public static AltManager altManager;
	
	
	
	public static void startClient() {
		
		altManager = new AltManager();
		
		
	}
	

}
