
package me.wavelength.baseclient.AltManager;

public class Alts {
}

