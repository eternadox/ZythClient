
package me.wavelength.baseclient.AltManager;

public class Info {
}

