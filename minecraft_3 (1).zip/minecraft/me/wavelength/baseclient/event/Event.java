package me.wavelength.baseclient.event;

public class Event {

	public Event() {
	}

}