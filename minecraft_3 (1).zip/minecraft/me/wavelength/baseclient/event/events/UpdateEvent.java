package me.wavelength.baseclient.event.events;

import me.wavelength.baseclient.event.Event;

public class UpdateEvent extends Event {

}