package me.wavelength.baseclient.event.events;

import me.wavelength.baseclient.event.Event;
import me.wavelength.baseclient.event.events.EventTick;

public class EventTick
  extends Event
{
  public EventTick() {}
}
