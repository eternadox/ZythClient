package me.wavelength.baseclient.module;

public enum Category {

	COMBAT, MOVEMENT, WORLD, PLAYER, EXPLOIT, RENDER, SEMI_HIDDEN, HIDDEN;

}