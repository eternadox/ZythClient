package me.wavelength.baseclient.module.modules.semi_hidden;

import me.wavelength.baseclient.module.Category;
import me.wavelength.baseclient.module.Module;

public class TabGui extends Module {

	public TabGui() {
		super("TabGui", "This is the TabGui", 0, Category.SEMI_HIDDEN, true, true);
	}

}