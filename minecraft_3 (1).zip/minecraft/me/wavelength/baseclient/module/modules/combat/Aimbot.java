package me.wavelength.baseclient.module.modules.combat;

import me.wavelength.baseclient.module.Category;
import me.wavelength.baseclient.module.Module;

public class Aimbot extends Module {
    public Aimbot() {
        super("Aimbot", "Auto rot aiming.", 0, Category.COMBAT);
    }
}