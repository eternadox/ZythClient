package net.minecraft.block;

public class BlockButtonWood extends BlockButton {
	protected BlockButtonWood() {
		super(true);
	}
}
